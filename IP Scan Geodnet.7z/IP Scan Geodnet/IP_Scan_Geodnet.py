import sys
import subprocess
import pkg_resources
import ctypes
import os

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)

def check_and_install_dependencies():
    required = {'scapy', 'netifaces', 'mac_vendor_lookup'}
    installed = {pkg.key for pkg in pkg_resources.working_set}
    missing = required - installed

    if missing:
        print("Installing missing dependencies...")
        python = sys.executable
        try:
            subprocess.check_call([python, '-m', 'pip', 'install', *missing], stdout=subprocess.DEVNULL)
            print("Dependencies installed successfully.")
        except subprocess.CalledProcessError:
            print("Failed to install dependencies. Please run the script with appropriate permissions.")
            sys.exit(1)
    else:
        print("All dependencies are already installed.")

# Now import the required modules
from scapy.all import ARP, Ether, srp
import ipaddress
import netifaces
from mac_vendor_lookup import MacLookup
import tkinter as tk
from tkinter import ttk
import webbrowser

def get_vendor(mac):
    try:
        return MacLookup().lookup(mac)
    except:
        return None

def get_network_info():
    gateways = netifaces.gateways()
    default_gateway = gateways['default'][netifaces.AF_INET][0]
    gateway_ip = ipaddress.ip_address(default_gateway)

    for interface in netifaces.interfaces():
        addrs = netifaces.ifaddresses(interface)
        if netifaces.AF_INET in addrs:
            for addr in addrs[netifaces.AF_INET]:
                ip = ipaddress.ip_address(addr['addr'])
                netmask = ipaddress.ip_address(addr['netmask'])
                network = ipaddress.ip_network(f"{ip}/{netmask}", strict=False)
                if gateway_ip in network:
                    return str(network)
    
    return f"{default_gateway.rsplit('.', 1)[0]}.0/24"

def scan_network(network):
    arp = ARP(pdst=str(network))
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    packet = ether/arp

    result = srp(packet, timeout=3, verbose=0)[0]

    devices = []
    for sent, received in result:
        vendor = get_vendor(received.hwsrc)
        if vendor and "espressif" in vendor.lower():
            devices.append({'ip': received.psrc, 'mac': received.hwsrc, 'vendor': vendor})

    return devices

def open_link(ip):
    webbrowser.open(f"http://{ip}")

def show_results(devices):
    root = tk.Tk()
    root.title("Espressif Devices")
    root.geometry("600x400")

    frame = ttk.Frame(root, padding="3 3 12 12")
    frame.grid(column=0, row=0, sticky=(tk.N, tk.W, tk.E, tk.S))
    root.columnconfigure(0, weight=1)
    root.rowconfigure(0, weight=1)

    tree = ttk.Treeview(frame, columns=('IP', 'MAC', 'Vendor'), show='headings')
    tree.heading('IP', text='IP Address')
    tree.heading('MAC', text='MAC Address')
    tree.heading('Vendor', text='Vendor')
    tree.column('IP', width=150)
    tree.column('MAC', width=150)
    tree.column('Vendor', width=200)
    tree.grid(column=0, row=0, sticky=(tk.N, tk.W, tk.E, tk.S))

    scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=tree.yview)
    tree.configure(yscroll=scrollbar.set)
    scrollbar.grid(column=1, row=0, sticky=(tk.N, tk.S))

    frame.columnconfigure(0, weight=1)
    frame.rowconfigure(0, weight=1)

    for device in devices:
        tree.insert('', tk.END, values=(device['ip'], device['mac'], device['vendor']))

    def open_selected():
        selected_item = tree.selection()[0]
        ip = tree.item(selected_item)['values'][0]
        open_link(ip)

    open_button = ttk.Button(frame, text="Open in Browser", command=open_selected)
    open_button.grid(column=0, row=1, pady=10)

    count_label = ttk.Label(frame, text=f"Total Espressif devices found: {len(devices)}")
    count_label.grid(column=0, row=2, pady=5)

    if not devices:
        no_devices_label = ttk.Label(frame, text="No Espressif devices found on the network.")
        no_devices_label.grid(column=0, row=0, pady=20)

    root.mainloop()

def main():
    if not is_admin():
        print("This script requires administrator privileges. Requesting elevation...")
        run_as_admin()
        return

    # Run the dependency check and installation
    check_and_install_dependencies()

    network = get_network_info()
    print(f"Detected network: {network}")

    try:
        ip_network = ipaddress.ip_network(network, strict=False)
    except ValueError:
        print("Invalid network address")
        return

    print(f"Scanning network: {ip_network}")
    devices = scan_network(ip_network)

    show_results(devices)

if __name__ == "__main__":
    main()