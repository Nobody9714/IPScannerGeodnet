# [IP Scanner Geodnet]

## Disclaimer
This program was created with assistance from Claude 3.5 Sonnet, an AI language model. Claude, the author of this program, nor the program itself are in any way affiliated with, endorsed by, or connected to Geodnet or any distributors. This is an independent project.

## Description
This is a python script that searches the network for network interface cards with the vendor "espressif", then displays them in a popup window that enables you to go to that device's IP address using your default web browser. This provides non tech savvy people an easy way to find the Geodnet Base station on their network without having knowledge of networking or how to navigate a network router's console.

## Installation
If you know how to run a python script, use "IP_Scan_Geodnet.py". The python script will automatically install any missing dependents. If you dont know how to run a python script, click "IP Scan Start.bat" and it will run the python script for you. Give it administrator privileges if prompted.

## Contact
I'm Nobody4696 on the official Geodnet discord and other discord servers in the crypto DePIN space.